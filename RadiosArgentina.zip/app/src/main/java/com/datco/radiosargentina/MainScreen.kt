package com.datco.radiosargentina

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(vm: RadioViewModel = viewModel()) {
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(vm.message) {
        vm.message?.let {
            snack.showSnackbar(it)
            vm.message = null
        }
    }

    val counts = remember(vm.stations) { vm.stations.groupingBy { it.province }.eachCount() }
    val filtered = remember(
        vm.stations, vm.province, vm.style, vm.band, vm.query, vm.onlyFavs, vm.favorites
    ) {
        val q = Classifier.norm(vm.query)
        vm.stations.filter { s ->
            (vm.province == "Todas" || s.province == vm.province) &&
                (vm.style == "Todos" || s.style == vm.style) &&
                (vm.band == "Todas" || s.band == vm.band) &&
                (!vm.onlyFavs || s.id in vm.favorites) &&
                (q.isBlank() || Classifier.norm(s.name).contains(q))
        }
    }

    val chipColors = FilterChipDefaults.filterChipColors(
        selectedContainerColor = Celeste,
        selectedLabelColor = Navy,
        selectedLeadingIconColor = Navy
    )

    Scaffold(
        topBar = { Header(vm) },
        bottomBar = { MiniPlayer(vm) },
        snackbarHost = { SnackbarHost(snack) }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            OutlinedTextField(
                value = vm.query,
                onValueChange = { vm.query = it },
                singleLine = true,
                placeholder = { Text("Buscar radio") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 8.dp)
            )

            Row(
                modifier = Modifier
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                listOf("Todas", "AM", "FM", "Web").forEach { b ->
                    FilterChip(
                        selected = vm.band == b,
                        onClick = { vm.band = b },
                        label = { Text(b) },
                        colors = chipColors
                    )
                }
                FilterChip(
                    selected = vm.onlyFavs,
                    onClick = { vm.onlyFavs = !vm.onlyFavs },
                    label = { Text("Favoritas") },
                    leadingIcon = { Icon(Icons.Filled.Favorite, contentDescription = null, modifier = Modifier.size(18.dp)) },
                    colors = chipColors
                )
            }

            ProvinceSelector(
                selected = vm.province,
                total = vm.stations.size,
                counts = counts,
                onSelect = { vm.province = it }
            )

            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(listOf("Todos") + Classifier.styles) { st ->
                    FilterChip(
                        selected = vm.style == st,
                        onClick = { vm.style = st },
                        label = { Text(st) },
                        colors = chipColors
                    )
                }
            }

            Text(
                "${filtered.size} radios",
                fontSize = 12.sp,
                color = GrisTexto,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp)
            )

            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (filtered.isEmpty()) {
                    if (vm.loading) {
                        CircularProgressIndicator(Modifier.align(Alignment.Center), color = CelesteDark)
                    } else {
                        Text(
                            "No hay radios con estos filtros",
                            color = GrisTexto,
                            modifier = Modifier.align(Alignment.Center)
                        )
                    }
                } else {
                    LazyColumn(Modifier.fillMaxSize()) {
                        items(filtered, key = { it.id }) { s ->
                            StationRow(
                                s = s,
                                isCurrent = vm.current?.id == s.id,
                                fav = s.id in vm.favorites,
                                onPlay = {
                                    if (vm.current?.id == s.id) vm.toggle() else vm.play(s)
                                },
                                onFav = { vm.toggleFav(s) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Header(vm: RadioViewModel) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Celeste)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Filled.Radio, contentDescription = null, tint = Navy)
        Spacer(Modifier.width(10.dp))
        Text(
            "Radios Argentinas",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = Navy,
            modifier = Modifier.weight(1f)
        )
        if (vm.loading) {
            CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp, color = Navy)
        } else {
            IconButton(onClick = { vm.load() }) {
                Icon(Icons.Filled.Refresh, contentDescription = "Actualizar", tint = Navy)
            }
        }
    }
}

@Composable
private fun ProvinceSelector(
    selected: String,
    total: Int,
    counts: Map<String, Int>,
    onSelect: (String) -> Unit
) {
    var open by remember { mutableStateOf(false) }
    Box(Modifier.padding(horizontal = 16.dp)) {
        OutlinedButton(onClick = { open = true }) {
            Text(if (selected == "Todas") "Provincia: Todas" else selected)
            Icon(Icons.Filled.ArrowDropDown, contentDescription = null)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            DropdownMenuItem(
                text = { Text("Todas ($total)") },
                onClick = { onSelect("Todas"); open = false }
            )
            (Classifier.provinces + Classifier.NONE).forEach { p ->
                val c = counts[p] ?: 0
                if (c > 0) {
                    DropdownMenuItem(
                        text = { Text("$p ($c)") },
                        onClick = { onSelect(p); open = false }
                    )
                }
            }
        }
    }
}

@Composable
private fun StationRow(
    s: Station,
    isCurrent: Boolean,
    fav: Boolean,
    onPlay: () -> Unit,
    onFav: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(if (isCurrent) CelesteLight else Color.Transparent)
            .clickable(onClick = onPlay)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier.size(44.dp).clip(CircleShape).background(Celeste),
            contentAlignment = Alignment.Center
        ) {
            Text(s.band, fontWeight = FontWeight.Bold, fontSize = if (s.band == "Web") 11.sp else 14.sp, color = Navy)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(s.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
            val kbps = if (s.bitrate > 0) " · ${s.bitrate} kbps" else ""
            Text(
                "${s.province} · ${s.style}$kbps",
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontSize = 12.sp,
                color = GrisTexto
            )
        }
        IconButton(onClick = onFav) {
            Icon(
                if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                contentDescription = "Favorita",
                tint = if (fav) Color(0xFFE53935) else GrisTexto
            )
        }
    }
}

@Composable
private fun MiniPlayer(vm: RadioViewModel) {
    val s = vm.current ?: return
    Surface(color = Celeste, shadowElevation = 8.dp, modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(s.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold, color = Navy)
                Text(
                    if (vm.buffering) "Conectando..." else "${s.band} · ${s.province}",
                    fontSize = 12.sp,
                    color = Navy
                )
            }
            if (vm.buffering) {
                CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp, color = Navy)
            } else {
                IconButton(onClick = { vm.toggle() }) {
                    Icon(
                        if (vm.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        contentDescription = if (vm.playing) "Pausar" else "Reproducir",
                        tint = Navy
                    )
                }
            }
            IconButton(onClick = { vm.stop() }) {
                Icon(Icons.Filled.Close, contentDescription = "Detener", tint = Navy)
            }
        }
    }
}
