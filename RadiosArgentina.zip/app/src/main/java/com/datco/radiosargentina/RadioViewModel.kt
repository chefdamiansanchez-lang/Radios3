package com.datco.radiosargentina

import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class RadioViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = StationRepository(app)
    private val prefs = app.getSharedPreferences("radios", Context.MODE_PRIVATE)

    var stations by mutableStateOf<List<Station>>(emptyList())
    var loading by mutableStateOf(false)
    var message by mutableStateOf<String?>(null)

    var favorites by mutableStateOf<Set<String>>(prefs.getStringSet("favs", emptySet())?.toSet() ?: emptySet())
    var province by mutableStateOf("Todas")
    var style by mutableStateOf("Todos")
    var band by mutableStateOf("Todas")
    var query by mutableStateOf("")
    var onlyFavs by mutableStateOf(false)

    var current by mutableStateOf<Station?>(null)
    var playing by mutableStateOf(false)
    var buffering by mutableStateOf(false)

    private var controller: MediaController? = null

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            playing = isPlaying
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            buffering = playbackState == Player.STATE_BUFFERING
        }

        override fun onPlayerError(error: PlaybackException) {
            playing = false
            buffering = false
            message = "No se pudo reproducir esta radio. Probá con otra."
        }
    }

    init {
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        future.addListener({
            try {
                val c = future.get()
                controller = c
                c.addListener(playerListener)
                playing = c.isPlaying
            } catch (e: Exception) {
                message = "No se pudo iniciar el reproductor"
            }
        }, ContextCompat.getMainExecutor(app))
        load()
    }

    fun load() {
        viewModelScope.launch {
            if (stations.isEmpty()) {
                stations = withContext(Dispatchers.IO) { repo.loadCache() }
            }
            loading = true
            try {
                stations = repo.refresh()
            } catch (e: Exception) {
                message = if (stations.isEmpty()) "Sin conexión. Probá de nuevo."
                else "Sin conexión: se muestra la última lista guardada"
            }
            loading = false
        }
    }

    fun play(s: Station) {
        val c = controller
        if (c == null) {
            message = "El reproductor todavía no está listo"
            return
        }
        current = s
        val uri = Uri.parse(s.url)
        val item = MediaItem.Builder()
            .setMediaId(s.id)
            .setUri(uri)
            .setRequestMetadata(MediaItem.RequestMetadata.Builder().setMediaUri(uri).build())
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(s.name)
                    .setArtist("${s.band} · ${s.province}")
                    .build()
            )
            .build()
        c.setMediaItem(item)
        c.prepare()
        c.play()
    }

    fun toggle() {
        val c = controller ?: return
        if (c.isPlaying) {
            c.pause()
        } else {
            if (c.playbackState == Player.STATE_IDLE) c.prepare()
            c.play()
        }
    }

    fun stop() {
        controller?.stop()
        controller?.clearMediaItems()
        current = null
        playing = false
        buffering = false
    }

    fun toggleFav(s: Station) {
        val n = favorites.toMutableSet()
        if (!n.add(s.id)) n.remove(s.id)
        favorites = n
        prefs.edit().putStringSet("favs", HashSet(n)).apply()
    }

    override fun onCleared() {
        controller?.removeListener(playerListener)
        controller?.release()
        controller = null
        super.onCleared()
    }
}
