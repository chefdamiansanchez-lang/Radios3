package com.datco.radiosargentina

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun DatcoSplash(onDone: () -> Unit) {
    val alpha = remember { Animatable(0f) }
    val scale = remember { Animatable(0.8f) }

    LaunchedEffect(Unit) {
        launch { alpha.animateTo(1f, tween(900)) }
        launch { scale.animateTo(1f, tween(900, easing = FastOutSlowInEasing)) }
        delay(2300)
        onDone()
    }

    Box(
        modifier = Modifier.fillMaxSize().background(Color(0xFF1B2028)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.alpha(alpha.value).scale(scale.value)
        ) {
            Box(
                modifier = Modifier
                    .size(96.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF007BC7), Color(0xFF00D2FF)))),
                contentAlignment = Alignment.Center
            ) {
                Text("D", fontSize = 56.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
            Spacer(Modifier.height(22.dp))
            Text(
                "DATCO",
                fontSize = 34.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 10.sp,
                color = Color.White
            )
            Spacer(Modifier.height(10.dp))
            Text(
                "Desarrollo Avanzado de Tecnologías\ny Códigos Operativos",
                fontSize = 12.sp,
                color = Color(0xFF9AA7B5),
                textAlign = TextAlign.Center
            )
        }
        Text(
            "Diseño de apps... y algo más",
            fontSize = 12.sp,
            color = Color(0xFF6F7C8A),
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 40.dp).alpha(alpha.value)
        )
    }
}
