package com.datco.radiosargentina

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Celeste = Color(0xFF74ACDF)
val CelesteLight = Color(0xFFE8F3FC)
val CelesteDark = Color(0xFF2E7BBF)
val Navy = Color(0xFF0B3B66)
val Sol = Color(0xFFF6B40E)
val GrisTexto = Color(0xFF5F6B7A)

@Composable
fun RadiosTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = CelesteDark,
            onPrimary = Color.White,
            secondary = Celeste,
            onSecondary = Navy,
            background = Color.White,
            surface = Color.White,
            onSurface = Color(0xFF1B2733)
        ),
        content = content
    )
}
