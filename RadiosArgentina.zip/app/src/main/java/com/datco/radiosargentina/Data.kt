package com.datco.radiosargentina

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.text.Normalizer

data class Station(
    val id: String,
    val name: String,
    val url: String,
    val province: String,
    val style: String,
    val band: String,
    val bitrate: Int
)

object Classifier {
    const val NONE = "Sin provincia"

    val provinces = listOf(
        "Buenos Aires", "Ciudad de Buenos Aires", "Catamarca", "Chaco", "Chubut", "Córdoba",
        "Corrientes", "Entre Ríos", "Formosa", "Jujuy", "La Pampa", "La Rioja", "Mendoza",
        "Misiones", "Neuquén", "Río Negro", "Salta", "San Juan", "San Luis", "Santa Cruz",
        "Santa Fe", "Santiago del Estero", "Tierra del Fuego", "Tucumán"
    )

    val styles = listOf(
        "Folklore", "Tango", "Cuarteto", "Cumbia", "Rock", "Pop", "Romántica", "Noticias",
        "Deportes", "Clásica y jazz", "Electrónica", "Religiosa", "Variada"
    )

    fun norm(s: String): String =
        Normalizer.normalize(s, Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
            .lowercase()
            .trim()

    private val cabaRx = Regex("""\bcaba\b|capital federal|ciudad autonoma|ciudad de buenos aires|buenos aires city|federal capital""")

    fun province(raw: String): String {
        val n = norm(raw)
        if (n.isBlank()) return NONE
        if (cabaRx.containsMatchIn(n)) return "Ciudad de Buenos Aires"
        for (p in provinces) {
            if (n.contains(norm(p))) return p
        }
        return NONE
    }

    private val styleRules = listOf(
        "Folklore" to Regex("""\b(folklor|folclor|folk|chamam|zamba|criollo)"""),
        "Tango" to Regex("""\btango"""),
        "Cuarteto" to Regex("""\bcuarteto"""),
        "Cumbia" to Regex("""\b(cumbia|tropical|bailanta)"""),
        "Rock" to Regex("""\brock"""),
        "Romántica" to Regex("""\b(romantic|balada)"""),
        "Noticias" to Regex("""\b(noticia|news|talk|informacion)"""),
        "Deportes" to Regex("""\b(deport|sport)"""),
        "Clásica y jazz" to Regex("""\b(classical|clasica|jazz|blues)"""),
        "Electrónica" to Regex("""\b(electro|techno|house|dance|trance)"""),
        "Religiosa" to Regex("""\b(cristian|religio|gospel|catolic|evangel)"""),
        "Pop" to Regex("""\b(pop|hits|top ?40)\b""")
    )

    fun style(tags: String, name: String): String {
        val t = norm("$tags $name")
        for ((label, rx) in styleRules) {
            if (rx.containsMatchIn(t)) return label
        }
        return "Variada"
    }

    private val amRx = Regex("""\bAM\b|\bAM ?\d{3,4}\b|\b\d{3,4} ?AM\b""")
    private val fmRx = Regex("""\bFM\b|\bFM ?\d{2,3}|\b\d{2,3}[.,]\d""")

    fun band(name: String): String {
        val n = name.uppercase()
        return when {
            amRx.containsMatchIn(n) -> "AM"
            fmRx.containsMatchIn(n) -> "FM"
            else -> "Web"
        }
    }
}

class StationRepository(private val context: Context) {

    private val cacheFile get() = File(context.filesDir, "stations_ar.json")

    fun loadCache(): List<Station> = try {
        if (cacheFile.exists()) parse(cacheFile.readText()) else emptyList()
    } catch (e: Exception) {
        emptyList()
    }

    suspend fun refresh(): List<Station> = withContext(Dispatchers.IO) {
        val body = download()
        val list = parse(body)
        if (list.isNotEmpty()) cacheFile.writeText(body)
        list
    }

    private fun download(): String {
        var last: Exception? = null
        for (host in listOf("de1", "nl1", "at1")) {
            try {
                val conn = URL(
                    "https://$host.api.radio-browser.info/json/stations/search" +
                        "?countrycode=AR&hidebroken=true&order=clickcount&reverse=true&limit=2000"
                ).openConnection() as HttpURLConnection
                conn.connectTimeout = 8000
                conn.readTimeout = 20000
                conn.setRequestProperty("User-Agent", "RadiosArgentina-DATCO/1.0")
                try {
                    return conn.inputStream.bufferedReader().use { it.readText() }
                } finally {
                    conn.disconnect()
                }
            } catch (e: Exception) {
                last = e
            }
        }
        throw last ?: IOException("Sin conexión")
    }

    private fun parse(body: String): List<Station> {
        val arr = JSONArray(body)
        val seen = HashSet<String>()
        val out = ArrayList<Station>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val url = o.optString("url_resolved").ifBlank { o.optString("url") }.trim()
            val name = o.optString("name").trim().replace(Regex("\\s+"), " ")
            if (name.isBlank() || !url.startsWith("http")) continue
            if (!seen.add(url)) continue
            out.add(
                Station(
                    id = o.optString("stationuuid").ifBlank { url },
                    name = name,
                    url = url,
                    province = Classifier.province(o.optString("state")),
                    style = Classifier.style(o.optString("tags"), name),
                    band = Classifier.band(name),
                    bitrate = o.optInt("bitrate")
                )
            )
        }
        return out
    }
}
